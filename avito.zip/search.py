import re
from pprint import pprint

page_source = ''

with open("page_source.html") as f:
    page_source = f.read()

ads = re.findall("\/kaliningrad\/.+?(?=\")", page_source)

ads = list(set(ads))
pprint(ads)
print(f"\n\n\n\t---\t{len(ads)}\t---")
